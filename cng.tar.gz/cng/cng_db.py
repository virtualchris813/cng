# This file contains variables used for connecting to the Postgres Database
#Database Host Name or IP Address
dbhost="D_HOST"
#Database Port, default is 5432
dbport="D_PORT"
#Postgres User
dbuser="D_USER"
#Postgres User Password
dbpass="D_PASS"
#Database Name
dbname="D_DB"
